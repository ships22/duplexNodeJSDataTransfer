const express = require('express');
const router = express.Router();

const productController = require('../controller/productController');

router.get('/', productController.list);
router.post('/add', productController.save);
router.get('/delete/:id', productController.delete);
router.get('/update/:id', productController.update);
router.post('/update/:id', productController.upddone);


module.exports = router;